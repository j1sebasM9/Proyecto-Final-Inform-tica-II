#include "EntrenadorMaestroArena.h"
#include "Obstaculo.h"
#include <cstdlib>
#include <cmath>
#include <algorithm>

EntrenadorMaestroArena::EntrenadorMaestroArena()
    : estrategiaActual(1)
    , contadorEmpujesJ1(0)
    , contadorEmpujesJ2(0)
    , temporizadorInactividad(0.0f)
    , tiempoParaSiguienteAccion(8.0f)
    , temporizadorFuego(15.0f)
    , radioPista(205.0f)
    , modoPlataforma(false)
    , plataformaXIzq(-300.0f)
    , plataformaXDer(300.0f)
    , plataformaY(80.0f)
{
    origenJ1        = Vector2D(-180.0f, -60.0f);
    origenJ2        = Vector2D(180.0f,  -60.0f);
    radioProteccion = 60.0f;
}

bool EntrenadorMaestroArena::esZonaSegura(const Vector2D& pos)
{
    float dist1 = (pos - origenJ1).magnitud();
    float dist2 = (pos - origenJ2).magnitud();
    if (dist1 < radioProteccion || dist2 < radioProteccion) return false;
    return true;
}

void EntrenadorMaestroArena::registrarPercepcion(const Vector2D& posJ1, const Vector2D& posJ2, bool huboColision, float dt)
{
    zonasFrecuentesJ1.push_back(posJ1);
    if (zonasFrecuentesJ1.size() > 30) {
        zonasFrecuentesJ1.erase(zonasFrecuentesJ1.begin());
    }

    zonasFrecuentesJ2.push_back(posJ2);
    if (zonasFrecuentesJ2.size() > 30) {
        zonasFrecuentesJ2.erase(zonasFrecuentesJ2.begin());
    }

    if (!huboColision) {
        temporizadorInactividad += dt;
    } else {
        temporizadorInactividad = 0.0f;
    }
}

Vector2D EntrenadorMaestroArena::calcularZonaCritica(int idJugador)
{
    const std::vector<Vector2D>& historial = (idJugador == 1) ? zonasFrecuentesJ1 : zonasFrecuentesJ2;

    if (historial.empty()) return Vector2D(0, 0);

    Vector2D suma(0, 0);
    for (const auto& pos : historial) suma = suma + pos;
    return suma * (1.0f / historial.size());
}

void EntrenadorMaestroArena::ejecutarAccionModeradora(std::vector<Obstaculo*>& obstaculosGlobales, float dt)
{
    // =========================================================================
    // MODO SUMO (Nivel 1: Geometria Polar)
    // =========================================================================
    if (!modoPlataforma) {
        temporizadorFuego -= dt;
        if (temporizadorFuego <= 0.0f) {
            bool hayFuegoActivo = false;
            for (Obstaculo* obs : obstaculosGlobales) {
                if (obs->getTipo() == FUEGO && obs->isActivo()) {
                    hayFuegoActivo = true;
                    break;
                }
            }

            if (!hayFuegoActivo) {
                const float RADIO_FUEGO = 25.0f;
                float       distMaxima  = radioPista - RADIO_FUEGO;
                Vector2D    posFuego;
                int         intentos    = 0;

                do {
                    float angulo    = (rand() % 360) * (3.141592f / 180.0f);
                    float factorR   = sqrt(static_cast<float>(rand()) / static_cast<float>(RAND_MAX));
                    float distancia = factorR * distMaxima;
                    posFuego        = Vector2D(distancia * cos(angulo), distancia * sin(angulo));
                    intentos++;
                } while (!esZonaSegura(posFuego) && intentos < 15);

                const float tiempoAviso = 2.5f;
                Obstaculo* fuego = new Obstaculo(FUEGO, posFuego, RADIO_FUEGO, tiempoAviso, true);
                obstaculosGlobales.push_back(fuego);

                temporizadorFuego = 15.0f + tiempoAviso;
            } else {
                temporizadorFuego = 2.0f;
            }
        }

        tiempoParaSiguienteAccion -= dt;
        if (tiempoParaSiguienteAccion <= 0.0f) {
            int      objetivo   = (rand() % 2) + 1;
            Vector2D zonaAtaque = calcularZonaCritica(objetivo);

            const float RADIO_RAYO = 25.0f;
            if (zonaAtaque.magnitud() > 1.0f && esZonaSegura(zonaAtaque) && zonaAtaque.magnitud() <= radioPista - RADIO_RAYO) {
                Obstaculo* rayo = new Obstaculo(RAYO_MODERADOR, zonaAtaque, RADIO_RAYO, 2.5f, true);
                obstaculosGlobales.push_back(rayo);
            }
            tiempoParaSiguienteAccion = 8.0f;
        }
        return;
    }

    // =========================================================================
    // MODO PLATAFORMA (Nivel 2: Geometria Lineal)
    // =========================================================================
    temporizadorFuego -= dt;
    if (temporizadorFuego <= 0.0f) {
        bool hayFuegoActivo = false;
        for (Obstaculo* obs : obstaculosGlobales) {
            if (obs->getTipo() == FUEGO && obs->isActivo()) {
                hayFuegoActivo = true;
                break;
            }
        }

        if (!hayFuegoActivo) {
            const float RADIO_FUEGO = 30.0f;
            const float yFuego      = plataformaY - 12.0f;
            const float aviso       = 2.0f;

            Vector2D posFuego;
            int intentos = 0;

            do {
                float rango = (plataformaXDer - RADIO_FUEGO) - (plataformaXIzq + RADIO_FUEGO);
                float xAleatorio = plataformaXIzq + RADIO_FUEGO + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / rango));

                posFuego = Vector2D(xAleatorio, yFuego);
                intentos++;
            } while (!esZonaSegura(posFuego) && intentos < 15);

            Obstaculo* fuego = new Obstaculo(FUEGO, posFuego, RADIO_FUEGO, aviso, false);
            obstaculosGlobales.push_back(fuego);

            temporizadorFuego = 15.0f + aviso;
        } else {
            temporizadorFuego = 2.0f;
        }
    }

    tiempoParaSiguienteAccion -= dt;
    if (tiempoParaSiguienteAccion <= 0.0f) {
        int      objetivo   = (rand() % 2) + 1;
        Vector2D zonaAtaque = calcularZonaCritica(objetivo);

        const float RADIO_RAYO = 25.0f;
        float xRayo = zonaAtaque.x;
        xRayo = std::max(plataformaXIzq + RADIO_RAYO, xRayo);
        xRayo = std::min(plataformaXDer - RADIO_RAYO, xRayo);
        float yRayo = plataformaY - 12.0f;

        Vector2D posRayo(xRayo, yRayo);

        if (esZonaSegura(posRayo)) {
            Obstaculo* rayo = new Obstaculo(RAYO_MODERADOR, posRayo, RADIO_RAYO, 2.5f, false);
            obstaculosGlobales.push_back(rayo);
        }
        tiempoParaSiguienteAccion = 8.0f;
    }
}

void EntrenadorMaestroArena::registrarEmpuje(int idJugador)
{
    if (idJugador == 1) contadorEmpujesJ1++;
    else                contadorEmpujesJ2++;
}

void EntrenadorMaestroArena::setZonasSeguras(Vector2D posJ1, Vector2D posJ2)
{
    origenJ1 = posJ1;
    origenJ2 = posJ2;
}