#include "Saltarin.h"
#include <cmath>
#include <QFileInfo>

static const float PI = 3.14159265f;

Saltarin::Saltarin(std::string _nom, float _x, float _y, float _r, float _m, QString rutaSprite)
    : Combatiente(_x, _y, _r, _m, rutaSprite)
    , nombre(_nom)
    , fuerzaSalto(600.0f)
    , direccionMirada(1)
    , carpetaSprites("")
    , spriteActual("idle.png")
    , tiempoAnimacionCaminar(0.0f)
    , tiempoSpriteBloqueado(0.0f)
    , frameCaminar(1)
{
    friccionSuperficie = 0.05f; // Friccion muy baja para el arquetipo agil
    QFileInfo infoSprite(rutaSprite);
    carpetaSprites = infoSprite.absolutePath() + "/";
}

void Saltarin::setModoSumo(bool estado)
{
    modoSumo = estado;
}

void Saltarin::setEnElSuelo(bool estado)
{
    enElSuelo = estado;
}

void Saltarin::setEnHielo(bool estado)
{
    if (estado) {
        if (friccionSuperficie > 0.01f) {
            friccionSuperficie = 0.0f; // Friccion cero absoluto

            if (velocidad.x > 10.0f) {
                velocidad.x += 15.0f;
            } else if (velocidad.x < -10.0f) {
                velocidad.x -= 15.0f;
            } else {
                velocidad.x += (direccionMirada * 15.0f);
            }
        }
    } else {
        friccionSuperficie = 0.05f; // Retorna a su friccion resbaladiza normal
    }
}

void Saltarin::mover(int accion)
{
    if (modoSumo) {
        if (accion == 1) {
            float dirX = std::cos(anguloOrientacion);
            float dirY = std::sin(anguloOrientacion);
            recibirImpulsoLineal(Vector2D(dirX, dirY) * 15000.0f);

            if (dirX < 0) {
                direccionMirada = -1;
                setDireccionVisual(-1);
            } else if (dirX > 0) {
                direccionMirada = 1;
                setDireccionVisual(1);
            }
        } else if (accion == 2) {
            velocidadAngular += 4.0f; // Rotacion rapida
        }
        return;
    }

    // Mecanicas de control para el Modo Plataforma (Nivel 2)
    const float fuerzaLateral = 150.0f; // Fuerza de empuje ligera
    if (accion == 1) {
        direccionMirada = -1;
        setDireccionVisual(-1);
        recibirImpulsoLineal(Vector2D(-fuerzaLateral, 0.0f));
    } else if (accion == 2) {
        direccionMirada = 1;
        setDireccionVisual(1);
        recibirImpulsoLineal(Vector2D(fuerzaLateral, 0.0f));
    } else if (accion == 3 && enElSuelo) {
        velocidad.y = -fuerzaSalto;
        enElSuelo = false;
        cambiarSpriteSaltarin("jump.png");
    } else if (accion == 4) {
        mostrarEmpujeVisual();
    }
}

void Saltarin::aplicarFisicas(float dt)
{
    if (modoSumo) {
        anguloOrientacion += velocidadAngular * dt;
        if (anguloOrientacion > 2 * PI) anguloOrientacion -= 2 * PI;

        setRotation((anguloOrientacion * (180.0f / PI)) - 90.0f);
        velocidadAngular *= (1.0f - 0.05f);
        posicion = posicion + (velocidad * dt);
        velocidad = velocidad * (1.0f - friccionSuperficie);
    } else {
        if (!enElSuelo) {
            velocidad.y += 980.0f * dt; // Gravedad estandar aplicada
        }
        posicion = posicion + (velocidad * dt);
        velocidad.x *= (1.0f - friccionSuperficie);
    }

    setPos(posicion.x, posicion.y);
    actualizarSpriteSaltarin(dt);
}

void Saltarin::cambiarSpriteSaltarin(const QString& archivo)
{
    if (archivo == spriteActual) return;
    spriteActual = archivo;
    cambiarSprite(carpetaSprites + archivo);
}

void Saltarin::actualizarSpriteSaltarin(float dt)
{
    if (modoSumo) return;
    if (tiempoSpriteBloqueado > 0.0f) {
        tiempoSpriteBloqueado -= dt;
        return;
    }

    if (!enElSuelo) {
        cambiarSpriteSaltarin(velocidad.y < 0.0f ? "jump.png" : "fall.png");
        return;
    }

    if (std::fabs(velocidad.x) > 25.0f) {
        tiempoAnimacionCaminar += dt;
        if (tiempoAnimacionCaminar >= 0.10f) { // Animacion de caminata mas veloz
            tiempoAnimacionCaminar = 0.0f;
            frameCaminar = (frameCaminar % 3) + 1;
        }
        cambiarSpriteSaltarin(QString("walk%1.png").arg(frameCaminar));
    } else {
        cambiarSpriteSaltarin("idle.png");
    }
}

void Saltarin::mostrarEmpujeVisual()
{
    tiempoSpriteBloqueado = 0.18f;
    cambiarSpriteSaltarin("push.png");
}