#ifndef NIVELBASE_H
#define NIVELBASE_H


#include <QGraphicsScene>
#include <QTimer>
#include <QGraphicsTextItem>
#include <QGraphicsPixmapItem>
#include <QKeyEvent>
#include <array>
#include <vector>

class Combatiente;
class Obstaculo;
class EntrenadorMaestroArena;

class NivelBase : public QGraphicsScene {
    Q_OBJECT

signals:
    void nivelTerminado(int idJugadorGanador);

public:
    explicit NivelBase(QObject *parent = nullptr);
    virtual ~NivelBase();

    void iniciarNivel();
    void pausarNivel();

    // Metodos polimorficos puros para definicion de reglas especificas
    virtual void verificarBordes() = 0;
    virtual void configurarEscenario() = 0;

public slots:
    void gameLoop();

protected:
    std::array<Combatiente*, 3> jugadores = {nullptr, nullptr, nullptr};
    std::vector<Obstaculo*> obstaculos;
    EntrenadorMaestroArena* agenteIA;

    QTimer* gameTimer;
    float dt;
    bool juegoTerminado = false;

    // Elementos de Interfaz de Usuario
    QGraphicsPixmapItem* panelUI_J1 = nullptr;
    QGraphicsPixmapItem* panelUI_J2 = nullptr;
    QGraphicsTextItem* uiVidasJ1 = nullptr;
    QGraphicsTextItem* uiVidasJ2 = nullptr;
    QGraphicsTextItem* uiPuntosJ1 = nullptr;
    QGraphicsTextItem* uiPuntosJ2 = nullptr;

    void crearPanelEstadisticas(int numJugador, QString rutaFondo, QString nombre, int vidasIniciales, float posX, float posY);
    void dibujarUI();
    void resolverColisionSumo(Combatiente* j1, Combatiente* j2);

    void keyPressEvent(QKeyEvent *event) override;
};
#endif // NIVELBASE_H
