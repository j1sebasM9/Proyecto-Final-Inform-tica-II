#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QKeyEvent>

class QMediaPlayer;
class QAudioOutput;
class NivelBase;


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }

QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    //  Flujo de inicio
    void on_btnStart_clicked();
    void finalizarTransicion();

    //  Flujo de niveles
    void mostrarTransicionVictoria(int idGanador); // Recibe señal del Nivel 1
    void iniciarNivel2();
    void terminarJuego(int idGanador);             // Recibe señal del Nivel 2

    //  Menú de pausa
    void on_btnVolverJugar_clicked();
    void on_btnSalir_clicked();
    void on_btnVolverInicio_clicked();

private:
    //  UI generada por Qt
    Ui::MainWindow *ui;

    //  Escenas
    QGraphicsScene *escenaMenu;
    NivelBase      *escenaJuego;

    //  Datos persistentes entre niveles
    int     eleccionJ1;
    int     eleccionJ2;
    QString nombreJ1;
    QString nombreJ2;
    int     faseActual;
    //  Audio
    QMediaPlayer  *musicaFondo;
    QAudioOutput  *salidaAudio;

    //  Helpers privados
    void iniciarMusicaFondo();
    void destruirNivelActual();
    void mostrarEscenaTransicion(const QString &rutaImagen);
    void conectarNivel(int fase);
};

#endif // MAINWINDOW_H