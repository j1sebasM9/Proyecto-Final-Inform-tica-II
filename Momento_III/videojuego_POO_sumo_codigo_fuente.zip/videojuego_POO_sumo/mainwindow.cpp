#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Nivel1.h"
#include "Nivel2.h"
#include <QImage>
#include <QBrush>
#include <QTimer>
#include <QUrl>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMessageBox>
#include <QFile>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , escenaMenu(nullptr)
    , escenaJuego(nullptr)
    , eleccionJ1(1)
    , eleccionJ2(2)
    , faseActual(1)
    , musicaFondo(nullptr)
    , salidaAudio(nullptr)
{
    ui->setupUi(this);

    // Configuracion de dimensiones de la ventana fija
    this->setFixedSize(800, 800);
    ui->graphicsView->setGeometry(0, 0, 800, 800);

    // Inicializacion del menu principal
    escenaMenu = new QGraphicsScene(this);
    escenaMenu->setSceneRect(0, 0, 800, 800);
    ui->graphicsView->setScene(escenaMenu);

    QImage imagenMenu("C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/mainofgame.png");
    if (!imagenMenu.isNull()) {
        ui->graphicsView->setBackgroundBrush(
            QBrush(imagenMenu.scaled(800, 800, Qt::KeepAspectRatio, Qt::SmoothTransformation))
            );
    }

    ui->capaMenuPausa->hide();
    iniciarMusicaFondo();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnStart_clicked()
{
    // Validacion de las elecciones de personajes (Rango 1 a 3)
    eleccionJ1 = ui->txtPersonajeJ1->text().toInt();
    eleccionJ2 = ui->txtPersonajeJ2->text().toInt();
    if (eleccionJ1 < 1 || eleccionJ1 > 3) eleccionJ1 = 1;
    if (eleccionJ2 < 1 || eleccionJ2 > 3) eleccionJ2 = 2;

    // Asignacion de nombres por defecto si estan vacios
    nombreJ1 = ui->txtNombreJ1->text();
    nombreJ2 = ui->txtNombreJ2->text();
    if (nombreJ1.isEmpty()) nombreJ1 = "JUGADOR 1";
    if (nombreJ2.isEmpty()) nombreJ2 = "JUGADOR 2";

    ui->txtNombreJ1->hide();
    ui->txtPersonajeJ1->hide();
    ui->txtNombreJ2->hide();
    ui->txtPersonajeJ2->hide();
    ui->btnStart->hide();

    // Limpieza de estilos para evitar artefactos visuales
    this->setStyleSheet("");
    ui->centralwidget->setStyleSheet("");
    ui->graphicsView->setStyleSheet("");
    ui->graphicsView->setBackgroundBrush(Qt::NoBrush);

    // Seleccion de imagen de transicion segun el enfrentamiento
    QString rutaTransicion;
    int a = eleccionJ1, b = eleccionJ2;
    if ((a == 1 && b == 2) || (a == 2 && b == 1))
        rutaTransicion = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_1vs2.png";
    else if ((a == 1 && b == 3) || (a == 3 && b == 1))
        rutaTransicion = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_1vs3.png";
    else if ((a == 2 && b == 3) || (a == 3 && b == 2))
        rutaTransicion = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_2vs3.png";
    else
        rutaTransicion = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_espejo.png";

    mostrarEscenaTransicion(rutaTransicion);
    QTimer::singleShot(3000, this, &MainWindow::finalizarTransicion);
}

void MainWindow::finalizarTransicion()
{
    faseActual = 1;
    escenaJuego = new Nivel1(eleccionJ1, eleccionJ2, nombreJ1, nombreJ2);
    conectarNivel(faseActual);

    ui->graphicsView->setScene(escenaJuego);
    escenaJuego->iniciarNivel();

    QString rutaMenu = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/menu.png";
    ui->capaMenuPausa->setStyleSheet("QFrame#capaMenuPausa { border-image: url(" + rutaMenu + "); }");
    ui->capaMenuPausa->show();
    ui->capaMenuPausa->raise();
}

void MainWindow::mostrarTransicionVictoria(int idGanador)
{
    ui->capaMenuPausa->hide();
    destruirNivelActual();

    // Carga de la pantalla intermedia de ganador del Nivel 1
    int tipoGanador = (idGanador == 1) ? eleccionJ1 : eleccionJ2;
    QString rutaVictoria;
    if      (tipoGanador == 1) rutaVictoria = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_ganador_fortachon.png";
    else if (tipoGanador == 2) rutaVictoria = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_ganador_saltarin.png";
    else                       rutaVictoria = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/transicion_ganador_pikachu.png";

    mostrarEscenaTransicion(rutaVictoria);
    QTimer::singleShot(3000, this, &MainWindow::iniciarNivel2);
}

void MainWindow::iniciarNivel2()
{
    faseActual = 2;
    escenaJuego = new Nivel2(eleccionJ1, eleccionJ2, nombreJ1, nombreJ2);
    conectarNivel(faseActual);

    ui->graphicsView->setScene(escenaJuego);
    escenaJuego->iniciarNivel();

    ui->capaMenuPausa->show();
    ui->capaMenuPausa->raise();
}

void MainWindow::terminarJuego(int idGanador)
{
    destruirNivelActual();

    // Determinacion del personaje ganador para construir la ruta de la imagen
    int tipoGanador = (idGanador == 1) ? eleccionJ1 : eleccionJ2;
    QString nombreArchivoPersonaje;
    if      (tipoGanador == 1) nombreArchivoPersonaje = "fortachon";
    else if (tipoGanador == 2) nombreArchivoPersonaje = "saltarin";
    else                       nombreArchivoPersonaje = "electrico";

    if (idGanador != 1 && idGanador != 2) nombreArchivoPersonaje = "fortachon";

    QString rutaImagenGanador = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/ganador_level2_" + nombreArchivoPersonaje + ".png";
    mostrarEscenaTransicion(rutaImagenGanador);

    // Reactivacion del menu de opciones final sobre la imagen de victoria
    QString rutaMenu = "C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/menu.png";
    ui->capaMenuPausa->setStyleSheet("QFrame#capaMenuPausa { border-image: url(" + rutaMenu + "); }");
    ui->capaMenuPausa->show();
    ui->capaMenuPausa->raise();
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (ui->btnStart->isVisible()) {
        QMainWindow::keyPressEvent(event);
        return;
    }

    // Gestion del menu de pausa mediante la tecla Escape
    if (event->key() == Qt::Key_Escape) {
        bool menuVisible = ui->capaMenuPausa->isVisible();
        ui->capaMenuPausa->setVisible(!menuVisible);

        if (menuVisible && escenaJuego) {
            escenaJuego->iniciarNivel();
        }
    }
}

void MainWindow::on_btnVolverJugar_clicked()
{
    destruirNivelActual();
    faseActual = 1;
    escenaJuego = new Nivel1(eleccionJ1, eleccionJ2, nombreJ1, nombreJ2);
    conectarNivel(faseActual);

    ui->graphicsView->setScene(escenaJuego);
    escenaJuego->iniciarNivel();

    ui->capaMenuPausa->show();
    ui->capaMenuPausa->raise();
}

void MainWindow::on_btnSalir_clicked()
{
    this->close();
}

void MainWindow::on_btnVolverInicio_clicked()
{
    destruirNivelActual();
    ui->capaMenuPausa->hide();

    ui->txtNombreJ1->show();
    ui->txtPersonajeJ1->show();
    ui->txtNombreJ2->show();
    ui->txtPersonajeJ2->show();
    ui->btnStart->show();

    ui->graphicsView->setScene(escenaMenu);
    QImage imagenMenu("C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/mainofgame.png");
    if (!imagenMenu.isNull()) {
        ui->graphicsView->setBackgroundBrush(
            QBrush(imagenMenu.scaled(800, 800, Qt::KeepAspectRatio, Qt::SmoothTransformation))
            );
    }
}

void MainWindow::destruirNivelActual()
{
    if (escenaJuego) {
        escenaJuego->pausarNivel();
        escenaJuego->disconnect();
        escenaJuego->deleteLater(); // Eliminacion segura en la cola de eventos de Qt
        escenaJuego = nullptr;
    }
}

void MainWindow::mostrarEscenaTransicion(const QString &rutaImagen)
{
    QGraphicsScene *escenaTemp = new QGraphicsScene(this);
    escenaTemp->setSceneRect(0, 0, 800, 800);

    QImage img(rutaImagen);
    if (!img.isNull()) {
        escenaTemp->setBackgroundBrush(
            QBrush(img.scaled(800, 800, Qt::KeepAspectRatio, Qt::SmoothTransformation))
            );
    }
    ui->graphicsView->setScene(escenaTemp);
}

void MainWindow::conectarNivel(int fase)
{
    if (!escenaJuego) return;

    if (fase == 1) {
        connect(escenaJuego, &NivelBase::nivelTerminado, this, &MainWindow::mostrarTransicionVictoria);
    } else {
        connect(escenaJuego, &NivelBase::nivelTerminado, this, &MainWindow::terminarJuego);
    }
}

void MainWindow::iniciarMusicaFondo()
{
    if (musicaFondo) return;

    salidaAudio = new QAudioOutput(this);
    salidaAudio->setVolume(1.0f);

    musicaFondo = new QMediaPlayer(this);
    musicaFondo->setAudioOutput(salidaAudio);
    musicaFondo->setSource(QUrl::fromLocalFile("C:/Users/sm713/Documents/videojuego_POO_sumo/spriters/audio/musica_fondo.mp3"));
    musicaFondo->setLoops(QMediaPlayer::Infinite);
    musicaFondo->play();
}