#include <QApplication>
#include "mainwindow.h" // ¡Cambiamos Nivel1.h por la ventana principal!

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    // Creamos la ventana principal (el menú) y le decimos que se muestre
    MainWindow w;
    w.show();

    // El juego ya no se inicia aquí. Será el botón "START" dentro de MainWindow
    // el que se encargará de crear y arrancar el Nivel1.

    return a.exec();
}