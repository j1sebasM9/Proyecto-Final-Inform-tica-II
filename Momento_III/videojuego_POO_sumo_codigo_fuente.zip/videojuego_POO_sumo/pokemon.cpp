/*#include "Pokemon.h"
#include <cmath>

// Constante matemática segura para evitar problemas con M_PI en Qt
const float PI = 3.14159265f;

// Implementación del Constructor
Pokemon::Pokemon(std::string _nom, float _x, float _y, float _r, float _m, QColor color)
    : Combatiente(_x, _y, _r, _m, color), nombre(_nom), habilidadEsp("Embestida")
{
    // El cuerpo del constructor queda vacío ya que Combatiente inicializa todo
}

// Implementación del Movimiento
void Pokemon::mover(int accion) {
    if (accion == 1) {
        // ACCIÓN 1: Salir disparado (Tecla E o 7)
        // Usamos la orientación que heredamos de Combatiente
        float dirX = std::cos(anguloOrientacion);
        float dirY = std::sin(anguloOrientacion);
        Vector2D vectorDirector(dirX, dirY);

        float fuerzaImpulso = 15000.0f; // Fuerza del empuje sumo
        recibirImpulsoLineal(vectorDirector * fuerzaImpulso);
    }
    else if (accion == 2) {
        // ACCIÓN 2: Dar un impulso de rotación (Tecla W u 8)
        velocidadAngular += 4.0f;
    }
}

// Implementación de las Físicas (Nivel 1)
void Pokemon::aplicarFisicas(float dt) {
    // 1. Rotación con inercia
    anguloOrientacion += velocidadAngular * dt;

    // Mantener el ángulo en el rango de [0, 2PI] para evitar desbordes matemáticos
    if (anguloOrientacion > 2 * PI) {
        anguloOrientacion -= 2 * PI;
    }

    // Sincronizar rotación con Qt (Conversión de Radianes a Grados)
    setRotation(anguloOrientacion * (180.0f / PI));

    // Fricción angular (Evita que el Pokémon gire eternamente como trompo)
    float friccionAngular = 0.05f;
    velocidadAngular = velocidadAngular * (1.0f - friccionAngular);




    posicion = posicion + (velocidad * dt);

    // 3. Aplicar fricción de la superficie de la arena (Deslizamiento lineal)
    velocidad = velocidad * (1.0f - friccionSuperficie);

    // 4. Sincronizar el modelo matemático visualmente en la escena de Qt
    setPos(posicion.x, posicion.y);
}

// Implementación de Habilidad
void Pokemon::usarHabilidad() {
    // Espacio para lógica polimórfica futura
}
*/