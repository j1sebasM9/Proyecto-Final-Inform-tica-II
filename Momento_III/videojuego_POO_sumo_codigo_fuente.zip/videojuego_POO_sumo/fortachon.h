#ifndef FORTACHON_H
#define FORTACHON_H


#include "Combatiente.h"
#include <string>
#include <QString>

class Fortachon : public Combatiente {
private:
    std::string nombre;
    float fuerzaEmpujeExtra;
    int   direccionMirada;

    QString carpetaSprites;
    QString spriteActual;
    float   tiempoAnimacionCaminar;
    float   tiempoSpriteBloqueado;
    int     frameCaminar;

    void cambiarSpriteFortachon(const QString& archivo);
    void actualizarSpriteFortachon(float dt);

public:
    Fortachon(std::string _nom, float _x, float _y, float _r, float _m, QString rutaSprite);

    // Implementacion de la interfaz polimorfica de Combatiente
    void mover(int accion)        override;
    void aplicarFisicas(float dt) override;

    // Sobrecarga de configuraciones de nivel 2
    void setModoSumo(bool estado)  override;
    void setEnElSuelo(bool estado) override;
    void setEnHielo(bool estado)   override;

    // Metodo unico de la especializacion
    void mostrarEmpujeVisual();
};

#endif // FORTACHON_H
