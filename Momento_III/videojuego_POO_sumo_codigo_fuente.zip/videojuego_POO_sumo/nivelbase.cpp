#include "NivelBase.h"
#include "Combatiente.h"
#include "Obstaculo.h"
#include "EntrenadorMaestroArena.h"
#include "PeleadorElectrico.h"
#include "Fortachon.h"
#include <QString>
#include <QDebug>

NivelBase::NivelBase(QObject *parent)
    : QGraphicsScene(parent)
    , dt(0.016f)
{
    agenteIA = new EntrenadorMaestroArena();
    gameTimer = new QTimer(this);
    connect(gameTimer, &QTimer::timeout, this, &NivelBase::gameLoop);
}

NivelBase::~NivelBase()
{
    delete agenteIA;
    for (auto obs : obstaculos) {
        delete obs;
    }
}

void NivelBase::iniciarNivel() { gameTimer->start(16); }
void NivelBase::pausarNivel() { gameTimer->stop(); }

void NivelBase::gameLoop()
{
    bool huboColision = false;

    // 1. Restauracion de fricciones base
    for (int i = 0; i < 3; i++) {
        if (jugadores[i]) jugadores[i]->setFriccionSuperficie(0.15f);
    }

    // 2. Integracion fisica y movimiento
    for (int i = 0; i < 3; i++) {
        if (jugadores[i] && jugadores[i]->getVidas() > 0) {
            jugadores[i]->aplicarFisicas(dt);
        }
    }

    // 3. Resolucion de colisiones entre combatientes
    for (int i = 0; i < 3; i++) {
        for (int j = i + 1; j < 3; j++) {
            if (jugadores[i] && jugadores[j] &&
                jugadores[i]->getVidas() > 0 && jugadores[j]->getVidas() > 0)
            {
                if (jugadores[i]->collidesWithItem(jugadores[j])) {
                    huboColision = true;
                    resolverColisionSumo(jugadores[i], jugadores[j]);
                    agenteIA->registrarEmpuje(i + 1);
                }
            }
        }
    }

    // 4. Registro y accion de la Inteligencia Artificial
    if (jugadores[0] && jugadores[1]) {
        agenteIA->registrarPercepcion(jugadores[0]->getPosicion(), jugadores[1]->getPosicion(), huboColision, dt);
    }

    int cantidadAnterior = obstaculos.size();
    agenteIA->ejecutarAccionModeradora(obstaculos, dt);

    if ((int)obstaculos.size() > cantidadAnterior) {
        addItem(obstaculos.back());
    }

    // 5. Actualizacion de obstaculos y aplicacion de efectos
    for (size_t i = 0; i < obstaculos.size(); i++) {
        if (obstaculos[i]->scene() == nullptr) addItem(obstaculos[i]);
        obstaculos[i]->actualizarObstaculo(dt);

        for (int j = 0; j < 3; j++) {
            if (jugadores[j] && jugadores[j]->collidesWithItem(obstaculos[i])) {
                int rival = (j == 0) ? 1 : 0;
                obstaculos[i]->aplicarEfecto(jugadores[j], jugadores[rival]);
            }
        }
    }

    // 6. Validaciones de entorno y UI
    verificarBordes();
    dibujarUI();

    // 7. Limpieza de memoria (Obstaculos inactivos)
    for (auto it = obstaculos.begin(); it != obstaculos.end(); ) {
        if (!(*it)->isActivo()) {
            removeItem(*it);
            delete *it;
            it = obstaculos.erase(it);
        } else {
            ++it;
        }
    }

    // 8. Control del estado de la partida
    if (!juegoTerminado) {
        if (jugadores[0] && jugadores[0]->getVidas() <= 0) {
            juegoTerminado = true;
            pausarNivel();
            qDebug() << "¡El Jugador 1 se quedo sin vidas!";
            emit nivelTerminado(2);
        } else if (jugadores[1] && jugadores[1]->getVidas() <= 0) {
            juegoTerminado = true;
            pausarNivel();
            qDebug() << "¡El Jugador 2 se quedo sin vidas!";
            emit nivelTerminado(1);
        } else if (jugadores[2] && jugadores[2]->getVidas() <= 0) {
            juegoTerminado = true;
            pausarNivel();
        }
    }
}

void NivelBase::dibujarUI()
{
    if (jugadores[0]) {
        if (uiVidasJ1) uiVidasJ1->setPlainText(QString::number(jugadores[0]->getVidas()));
        if (uiPuntosJ1) uiPuntosJ1->setPlainText(QString::number(jugadores[0]->getPuntos()));
    }

    if (jugadores[1]) {
        if (uiVidasJ2) uiVidasJ2->setPlainText(QString::number(jugadores[1]->getVidas()));
        if (uiPuntosJ2) uiPuntosJ2->setPlainText(QString::number(jugadores[1]->getPuntos()));
    }
}

void NivelBase::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_W) jugadores[0]->mover(2);
    if (event->key() == Qt::Key_E) jugadores[0]->mover(1);
    if (event->key() == Qt::Key_Q) jugadores[0]->mover(3);
    if (event->key() == Qt::Key_R) jugadores[0]->mover(4);

    if (event->key() == Qt::Key_8 || event->key() == Qt::Key_Up) jugadores[1]->mover(2);
    if (event->key() == Qt::Key_7 || event->key() == Qt::Key_Right) jugadores[1]->mover(1);
    if (event->key() == Qt::Key_Down) jugadores[1]->mover(3);
    if (event->key() == Qt::Key_9 || event->key() == Qt::Key_Left) jugadores[1]->mover(4);

    if (jugadores[2]) {
        if (event->key() == Qt::Key_K) jugadores[2]->mover(2);
        if (event->key() == Qt::Key_L) jugadores[2]->mover(1);
        if (event->key() == Qt::Key_P) jugadores[2]->mover(3);
        if (event->key() == Qt::Key_O) jugadores[2]->mover(4);
    }
}

void NivelBase::resolverColisionSumo(Combatiente* j1, Combatiente* j2)
{
    Vector2D normal = j2->getPosicion() - j1->getPosicion();
    float distancia = normal.magnitud();

    if (distancia == 0.0f) return;
    normal = normal.normalizar();

    float superposicion = (j1->getRadio() + j2->getRadio()) - distancia;
    if (superposicion > 0.0f) {
        j1->setPosicion(j1->getPosicion() - (normal * (superposicion * 0.5f)));
        j2->setPosicion(j2->getPosicion() + (normal * (superposicion * 0.5f)));
    }

    Vector2D velRelativa = j1->getVelocidad() - j2->getVelocidad();
    float velAproximacion = velRelativa.punto(normal);

    if (velAproximacion < 0.0f) return;

    float epsilon = 0.6f;
    float impulsoMag = (1.0f + epsilon) * velAproximacion / ((1.0f / j1->getMasa()) + (1.0f / j2->getMasa()));
    Vector2D vectorImpulso = normal * impulsoMag;

    float multJ1 = (dynamic_cast<PeleadorElectrico*>(j1)) ? 3.0f : 1.0f;
    float multJ2 = (dynamic_cast<PeleadorElectrico*>(j2)) ? 3.0f : 1.0f;

    if (dynamic_cast<Fortachon*>(j1) != nullptr) multJ2 *= 1.5f;
    if (dynamic_cast<Fortachon*>(j2) != nullptr) multJ1 *= 1.5f;

    j1->setVelocidad(j1->getVelocidad() - (vectorImpulso * (1.0f / j1->getMasa()) * multJ1));
    j2->setVelocidad(j2->getVelocidad() + (vectorImpulso * (1.0f / j2->getMasa()) * multJ2));
}

void NivelBase::crearPanelEstadisticas(int numJugador, QString rutaFondo, QString nombre, int vidasIniciales, float posX, float posY)
{
    QGraphicsPixmapItem* fondo = new QGraphicsPixmapItem();
    QImage imgUI(rutaFondo);

    fondo->setPixmap(QPixmap::fromImage(imgUI.scaled(220, 150, Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
    fondo->setPos(posX, posY);
    fondo->setZValue(10);
    fondo->setVisible(true);
    addItem(fondo);

    if (numJugador == 1) panelUI_J1 = fondo;
    else panelUI_J2 = fondo;

    QFont fuentePokemon("Arial", 12, QFont::Bold);

    QGraphicsTextItem* textoNombre = new QGraphicsTextItem(fondo);
    textoNombre->setFont(fuentePokemon);
    textoNombre->setDefaultTextColor(Qt::black);
    textoNombre->setPos(115, 78);
    textoNombre->setPlainText(nombre);

    QGraphicsTextItem* textoVidas = new QGraphicsTextItem(fondo);
    textoVidas->setFont(fuentePokemon);
    textoVidas->setDefaultTextColor(Qt::black);
    textoVidas->setPos(105, 113);
    textoVidas->setPlainText(QString::number(vidasIniciales));

    if (numJugador == 1) uiVidasJ1 = textoVidas;
    else uiVidasJ2 = textoVidas;

    QGraphicsTextItem* textoPuntos = new QGraphicsTextItem(fondo);
    textoPuntos->setFont(fuentePokemon);
    textoPuntos->setDefaultTextColor(Qt::black);
    textoPuntos->setPos(185, 115);
    textoPuntos->setPlainText("0");

    if (numJugador == 1) uiPuntosJ1 = textoPuntos;
    else uiPuntosJ2 = textoPuntos;
}