#ifndef PELEADORELECTRICO_H
#define PELEADORELECTRICO_H


#include "Combatiente.h"
#include "Obstaculo.h"
#include <vector>
#include <QString>

class PeleadorElectrico : public Combatiente {
private:
    int direccionMirada;
    std::vector<Obstaculo*>* referenciaObstaculosNivel;

    QString carpetaSprites;
    QString spriteActual;
    float tiempoAnimacionCaminar;
    float tiempoSpriteBloqueado;
    int frameCaminar;

    void cambiarSpriteElectrico(const QString& archivo);
    void actualizarSpriteElectrico(float dt);

public:
    PeleadorElectrico(float _x, float _y, QString rutaSprite, std::vector<Obstaculo*>& listaObstaculos);

    // Implementacion de la interfaz polimorfica de Combatiente
    void mover(int accion) override;
    void aplicarFisicas(float dt) override;

    // Habilidades unicas del personaje
    void lanzarRayoAtaque();
    void mostrarAtaqueVisual();

    // Sobrecarga de configuraciones de nivel 2
    void setModoSumo(bool estado) override;
    void setEnElSuelo(bool estado) override;
    void setEnHielo(bool estado) override;
};
#endif // PELEADORELECTRICO_H
