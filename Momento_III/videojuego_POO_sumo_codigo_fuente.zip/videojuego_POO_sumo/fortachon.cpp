#include "Fortachon.h"
#include <cmath>
#include <QFileInfo>

static const float PI = 3.14159265f;

Fortachon::Fortachon(std::string _nom, float _x, float _y, float _r, float _m, QString rutaSprite)
    : Combatiente(_x, _y, _r, _m, rutaSprite)
    , nombre(_nom)
    , fuerzaEmpujeExtra(400.0f)
    , direccionMirada(1)
    , carpetaSprites("")
    , spriteActual("idle.png")
    , tiempoAnimacionCaminar(0.0f)
    , tiempoSpriteBloqueado(0.0f)
    , frameCaminar(1)
{
    friccionSuperficie = 0.25f; // Mayor friccion base que define su peso
    QFileInfo infoSprite(rutaSprite);
    carpetaSprites = infoSprite.absolutePath() + "/";
}

void Fortachon::setModoSumo(bool estado)
{
    modoSumo = estado;
}

void Fortachon::setEnElSuelo(bool estado)
{
    enElSuelo = estado;
}

void Fortachon::setEnHielo(bool estado)
{
    if (estado) {
        if (friccionSuperficie > 0.01f) {
            friccionSuperficie = 0.0f; // Friccion cero absoluto en superficies deslizantes

            // Impulso por inercia de entrada
            if (velocidad.x > 10.0f) {
                velocidad.x += 15.0f;
            } else if (velocidad.x < -10.0f) {
                velocidad.x -= 15.0f;
            } else {
                velocidad.x += (direccionMirada * 15.0f);
            }
        }
    } else {
        friccionSuperficie = 0.25f; // Restaura su alto agarre caracteristico
    }
}

void Fortachon::mover(int accion)
{
    if (modoSumo) {
        if (accion == 1) {
            float dirX = std::cos(anguloOrientacion);
            float dirY = std::sin(anguloOrientacion);
            recibirImpulsoLineal(Vector2D(dirX, dirY) * 18000.0f); // Fuerza de empuje masiva

            if (dirX < 0) {
                direccionMirada = -1;
                setDireccionVisual(-1);
            } else if (dirX > 0) {
                direccionMirada = 1;
                setDireccionVisual(1);
            }
        } else if (accion == 2) {
            velocidadAngular += 2.5f; // Rotacion mas lenta debido a su gran masa
        }
        return;
    }

    // Mecanicas de control para el Modo Plataforma (Nivel 2)
    if (accion == 1) {
        direccionMirada = -1;
        setDireccionVisual(-1);
        recibirImpulsoLineal(Vector2D(-fuerzaEmpujeExtra, 0.0f));
    } else if (accion == 2) {
        direccionMirada = 1;
        setDireccionVisual(1);
        recibirImpulsoLineal(Vector2D(fuerzaEmpujeExtra, 0.0f));
    } else if (accion == 3 && enElSuelo) {
        velocidad.y = -650.0f; // Magnitud de salto calibrada para su peso
        enElSuelo = false;
        cambiarSpriteFortachon("jump.png");
    } else if (accion == 4) {
        mostrarEmpujeVisual();
    }
}

void Fortachon::aplicarFisicas(float dt)
{
    if (modoSumo) {
        anguloOrientacion += velocidadAngular * dt;
        if (anguloOrientacion > 2 * PI) anguloOrientacion -= 2 * PI;

        setRotation((anguloOrientacion * (180.0f / PI)) - 90.0f);
        velocidadAngular *= (1.0f - 0.08f);
        posicion = posicion + (velocidad * dt);
        velocidad = velocidad * (1.0f - friccionSuperficie);
    } else {
        if (!enElSuelo) {
            velocidad.y += 980.0f * dt; // Gravedad estandar aplicada
        }
        posicion = posicion + (velocidad * dt);
        velocidad.x *= (1.0f - friccionSuperficie);
    }

    setPos(posicion.x, posicion.y);
    actualizarSpriteFortachon(dt);
}

void Fortachon::cambiarSpriteFortachon(const QString& archivo)
{
    if (archivo == spriteActual) return;
    spriteActual = archivo;
    cambiarSprite(carpetaSprites + archivo);
}

void Fortachon::actualizarSpriteFortachon(float dt)
{
    if (modoSumo) return;
    if (tiempoSpriteBloqueado > 0.0f) {
        tiempoSpriteBloqueado -= dt;
        return;
    }

    if (!enElSuelo) {
        cambiarSpriteFortachon(velocidad.y < 0.0f ? "jump.png" : "fall.png");
        return;
    }

    if (std::fabs(velocidad.x) > 25.0f) {
        tiempoAnimacionCaminar += dt;
        if (tiempoAnimacionCaminar >= 0.14f) { // Animacion de caminata ligeramente mas lenta/pesada
            tiempoAnimacionCaminar = 0.0f;
            frameCaminar = (frameCaminar % 3) + 1;
        }
        cambiarSpriteFortachon(QString("walk%1.png").arg(frameCaminar));
    } else {
        cambiarSpriteFortachon("idle.png");
    }
}

void Fortachon::mostrarEmpujeVisual()
{
    tiempoSpriteBloqueado = 0.18f;
    cambiarSpriteFortachon("push.png");
}