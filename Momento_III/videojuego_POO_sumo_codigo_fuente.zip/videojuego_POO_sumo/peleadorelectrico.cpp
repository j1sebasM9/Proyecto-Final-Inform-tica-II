#include "PeleadorElectrico.h"
#include <cmath>
#include <QFileInfo>
#include <QGraphicsScene>

static const float PI = 3.14159265f;

PeleadorElectrico::PeleadorElectrico(float _x, float _y, QString rutaSprite, std::vector<Obstaculo*>& listaObstaculos)
    : Combatiente(_x, _y, 22.0f, 20.0f, rutaSprite)
    , direccionMirada(1)
    , referenciaObstaculosNivel(&listaObstaculos)
    , carpetaSprites("")
    , spriteActual("idle.png")
    , tiempoAnimacionCaminar(0.0f)
    , tiempoSpriteBloqueado(0.0f)
    , frameCaminar(1)
{
    friccionSuperficie = 0.10f;
    QFileInfo infoSprite(rutaSprite);
    carpetaSprites = infoSprite.absolutePath() + "/";
}

void PeleadorElectrico::setModoSumo(bool estado)
{
    modoSumo = estado;
}

void PeleadorElectrico::setEnElSuelo(bool estado)
{
    enElSuelo = estado;
}

void PeleadorElectrico::setEnHielo(bool estado)
{
    if (estado) {
        if (friccionSuperficie > 0.01f) {
            friccionSuperficie = 0.0f; // Friccion cero absoluto

            // Aplicacion de impulso inicial segun inercia de entrada
            if (velocidad.x > 10.0f) {
                velocidad.x += 15.0f;
            } else if (velocidad.x < -10.0f) {
                velocidad.x -= 15.0f;
            } else {
                // Desplazamiento por defecto basado en orientacion visual
                velocidad.x += (direccionMirada * 15.0f);
            }
        }
    } else {
        friccionSuperficie = 0.10f; // Recuperacion de traccion normal
    }
}

void PeleadorElectrico::mover(int accion)
{
    if (modoSumo) {
        if (accion == 1) {
            float dirX = std::cos(anguloOrientacion);
            float dirY = std::sin(anguloOrientacion);
            recibirImpulsoLineal(Vector2D(dirX, dirY) * 15000.0f);

            if (dirX < 0) {
                direccionMirada = -1;
                setDireccionVisual(-1);
            } else if (dirX > 0) {
                direccionMirada = 1;
                setDireccionVisual(1);
            }
        } else if (accion == 2) {
            velocidadAngular += 4.0f;
        } else if (accion == 4) {
            lanzarRayoAtaque();
        }
        return;
    }

    // Configuralas mecanicas de control para el Modo Plataforma (Nivel 2)
    const float fuerza = 200.0f;
    if (accion == 1) {
        direccionMirada = -1;
        setDireccionVisual(-1);
        recibirImpulsoLineal(Vector2D(-fuerza, 0.0f));
    } else if (accion == 2) {
        direccionMirada = 1;
        setDireccionVisual(1);
        recibirImpulsoLineal(Vector2D(fuerza, 0.0f));
    } else if (accion == 3 && enElSuelo) {
        velocidad.y = -500.0f;
        enElSuelo = false;
        cambiarSpriteElectrico("jump.png");
    } else if (accion == 4) {
        lanzarRayoAtaque();
        mostrarAtaqueVisual();
    }
}

void PeleadorElectrico::lanzarRayoAtaque()
{
    if (!referenciaObstaculosNivel) return;

    Vector2D dir(static_cast<float>(direccionMirada), 0.0f);
    if (modoSumo) {
        dir = Vector2D(std::cos(anguloOrientacion), std::sin(anguloOrientacion));
    }

    float distancia = radio + 15.0f;
    Vector2D posRayo = posicion + (dir * distancia);

    // Instanciacion del proyectil como un tipo de obstaculo activo
    Obstaculo* rayo = new Obstaculo(RAYO_ELECTRICO, posRayo, 18.0f, 0.0f, modoSumo);
    rayo->setVelocidadMovimiento(dir * 550.0f);
    rayo->setZValue(6);

    referenciaObstaculosNivel->push_back(rayo);

    if (this->scene()) {
        this->scene()->addItem(rayo);
    }
}

void PeleadorElectrico::aplicarFisicas(float dt)
{
    if (modoSumo) {
        anguloOrientacion += velocidadAngular * dt;
        if (anguloOrientacion > 2 * PI) anguloOrientacion -= 2 * PI;

        setRotation((anguloOrientacion * (180.0f / PI)) - 90.0f);
        velocidadAngular *= (1.0f - 0.05f);
        posicion = posicion + (velocidad * dt);
        velocidad = velocidad * (1.0f - friccionSuperficie);
    } else {
        if (!enElSuelo) {
            velocidad.y += 1000.0f * dt; // Gravedad basica aplicada
        }
        posicion = posicion + (velocidad * dt);
        velocidad.x *= (1.0f - friccionSuperficie);
    }

    setPos(posicion.x, posicion.y);
    actualizarSpriteElectrico(dt);
}

void PeleadorElectrico::cambiarSpriteElectrico(const QString& archivo)
{
    if (archivo == spriteActual) return;
    spriteActual = archivo;
    cambiarSprite(carpetaSprites + archivo);
}

void PeleadorElectrico::actualizarSpriteElectrico(float dt)
{
    if (modoSumo) {
        if (tiempoSpriteBloqueado > 0.0f) {
            tiempoSpriteBloqueado -= dt;
            if (tiempoSpriteBloqueado <= 0.0f) {
                cambiarSprite(carpetaSprites + "electrico.png"); // Restaura la apariencia esferica
            }
        }
        return;
    }

    // Procesamiento de la maquina de animacion para Modo Plataforma
    if (tiempoSpriteBloqueado > 0.0f) {
        tiempoSpriteBloqueado -= dt;
        return;
    }

    if (!enElSuelo) {
        cambiarSpriteElectrico(velocidad.y < 0.0f ? "jump.png" : "fall.png");
        return;
    }

    if (std::fabs(velocidad.x) > 25.0f) {
        tiempoAnimacionCaminar += dt;
        if (tiempoAnimacionCaminar >= 0.12f) {
            tiempoAnimacionCaminar = 0.0f;
            frameCaminar = (frameCaminar % 3) + 1;
        }
        cambiarSpriteElectrico(QString("walk%1.png").arg(frameCaminar));
    } else {
        cambiarSpriteElectrico("idle.png");
    }
}

void PeleadorElectrico::mostrarAtaqueVisual()
{
    tiempoSpriteBloqueado = 0.18f;
    cambiarSpriteElectrico("push.png");
}