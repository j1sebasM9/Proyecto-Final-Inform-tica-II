#ifndef SALTARIN_H
#define SALTARIN_H


#include "Combatiente.h"
#include <string>
#include <QString>

class Saltarin : public Combatiente {
private:
    std::string nombre;
    float fuerzaSalto;
    int   direccionMirada;

    QString carpetaSprites;
    QString spriteActual;
    float   tiempoAnimacionCaminar;
    float   tiempoSpriteBloqueado;
    int     frameCaminar;

    void cambiarSpriteSaltarin(const QString& archivo);
    void actualizarSpriteSaltarin(float dt);

public:
    Saltarin(std::string _nom, float _x, float _y, float _r, float _m, QString rutaSprite);

    // Implementacion de la interfaz polimorfica obligatoria
    void mover(int accion)        override;
    void aplicarFisicas(float dt) override;

    // Sobrecarga de configuraciones de Nivel 2
    void setModoSumo(bool estado)  override;
    void setEnElSuelo(bool estado) override;
    void setEnHielo(bool estado)   override;

    // Metodo de animacion reactiva
    void mostrarEmpujeVisual();
};
#endif // SALTARIN_H
