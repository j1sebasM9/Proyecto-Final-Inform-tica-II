#ifndef ENTRENADORMAESTROARENA_H
#define ENTRENADORMAESTROARENA_H


#include <vector>
#include "Vector2D.h"

class Obstaculo;

class EntrenadorMaestroArena {
private:
    int estrategiaActual;
    std::vector<Vector2D> zonasFrecuentesJ1;
    std::vector<Vector2D> zonasFrecuentesJ2;
    int contadorEmpujesJ1;
    int contadorEmpujesJ2;

    float temporizadorInactividad;
    float tiempoParaSiguienteAccion;
    float temporizadorFuego;
    Vector2D origenJ1;
    Vector2D origenJ2;
    float radioProteccion;

    // Entorno Nivel 1
    float radioPista;

    // Entorno Nivel 2
    bool  modoPlataforma;
    float plataformaXIzq;
    float plataformaXDer;
    float plataformaY;

    bool esZonaSegura(const Vector2D& pos);

public:
    EntrenadorMaestroArena();

    // Configuracion de Entorno Espacial
    void setZonasSeguras(Vector2D posJ1, Vector2D posJ2);
    void setRadioPista(float radio) { radioPista = radio; }
    void setModoPlataforma(bool modo, float xIzq = -300.0f, float xDer = 300.0f, float y = 80.0f) {
        modoPlataforma = modo;
        plataformaXIzq = xIzq;
        plataformaXDer = xDer;
        plataformaY    = y;
    }

    // 1. Fase de Percepcion
    void registrarPercepcion(const Vector2D& posJ1, const Vector2D& posJ2, bool huboColision, float dt);
    void registrarEmpuje(int idJugador);

    // 2. Fase de Razonamiento Analitico
    Vector2D calcularZonaCritica(int idJugador);

    // 3. Fase de Despliegue Tactico
    void ejecutarAccionModeradora(std::vector<Obstaculo*>& obstaculosGlobales, float dt);
};
#endif // ENTRENADORMAESTROARENA_H
