#ifndef POKEMON_H
#define POKEMON_H


#include "Combatiente.h"
#include <string>

class Pokemon : public Combatiente {
private:
    std::string nombre;
    std::string habilidadEsp;

public:
    // Constructor
    Pokemon(std::string _nom, float _x, float _y, float _r, float _m, QColor color);

    // Sobreescritura de los métodos polimórficos
    void mover(int accion) override;
    void aplicarFisicas(float dt) override;

    // Métodos propios de esta clase
    void usarHabilidad();
};

#endif // POKEMON_H
