#ifndef COMBATIENTE_H
#define COMBATIENTE_H


#include <QGraphicsEllipseItem>
#include <QPixmap>
#include <QPainter>
#include "Vector2D.h"

class Combatiente : public QGraphicsEllipseItem {
protected:
    Vector2D posicion;
    Vector2D posicionOrigen;
    Vector2D velocidad;
    float    masa;
    float    radio;
    float    friccionBase;
    float    friccionSuperficie;
    float    anguloOrientacion;
    float    velocidadAngular;
    bool     estaVivo;
    int      vidas;
    int      puntos;
    QPixmap  pixmapSprite;
    int      direccionVisual;

    // Estado para el modo plataforma (Nivel 2)
    bool enElSuelo = false;
    bool modoSumo  = true;

public:
    Combatiente(float _x, float _y, float _r, float _m, QString rutaSprite);
    virtual ~Combatiente() = default;

    // Metodos heredados de Qt para renderizado y colision
    void   paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) override;
    QRectF boundingRect() const override;

    // Gestion de recursos visuales
    void cambiarSprite(const QString& rutaSprite);
    void setDireccionVisual(int direccion);

    // Interfaz polimorfica pura obligatoria para las subclases
    virtual void mover(int accion)       = 0;
    virtual void aplicarFisicas(float dt) = 0;

    // Interfaz virtual de configuracion de estados
    virtual void setModoSumo(bool estado)  { modoSumo   = estado; }
    virtual void setEnElSuelo(bool estado) { enElSuelo = estado; }
    virtual void setEnHielo(bool enHielo);

    bool getModoSumo()  const { return modoSumo;  }
    bool getEnElSuelo() const { return enElSuelo; }

    // Mecanica de impulsos fisicos
    void recibirImpulsoLineal(const Vector2D& J);
    void recibirImpulsoAngular(float torque);

    // Reglas de negocio del personaje
    void perderVida(int cantidad = 1) {
        vidas -= cantidad;
        if (vidas <= 0) { vidas = 0; estaVivo = false; }
    }
    void ganarPunto();
    void regresarAlOrigen();
    void resetVidas();

    // Getters y Setters directos
    int             getVidas()    const;
    int             getPuntos()   const;
    void            setPuntos(int p);
    const Vector2D& getPosicion() const;
    void            setPosicion(const Vector2D& p);
    const Vector2D& getVelocidad() const;
    void            setVelocidad(const Vector2D& v);
    float           getRadio()    const;
    float           getMasa()     const;
    void            setFriccionSuperficie(float f);
    void            setAnguloOrientacion(float a);
};
#endif // COMBATIENTE_H
